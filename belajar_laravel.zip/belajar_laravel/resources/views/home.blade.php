<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Home Page</title>
    </head>
    <body>
        <h1>Welcome to Laravel Home Page</h1>
        <p>This is a sample page.</p>
    </body>
</html>