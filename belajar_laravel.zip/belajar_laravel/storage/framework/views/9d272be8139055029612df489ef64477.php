<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Dashboard</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('login.form')); ?>">Login</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('barang.index')); ?>">Data Barang</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('transaksi.index')); ?>">Data Transaksi</a>
            </li>
        </ul>
    </div>
</nav><?php /**PATH D:\xampp\htdocs\PHP1\belajar_laravel\resources\views/partials/navbar.blade.php ENDPATH**/ ?>